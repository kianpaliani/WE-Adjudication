module.exports = {
    reporters: ['lcov', 'html', 'text-summary']
};
