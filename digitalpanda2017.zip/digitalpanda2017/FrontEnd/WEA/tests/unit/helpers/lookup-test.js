
import { lookup } from 'students-records/helpers/lookup';
import { module, test } from 'qunit';

module('Unit | Helper | lookup');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = lookup([42]);
  assert.ok(result);
});

